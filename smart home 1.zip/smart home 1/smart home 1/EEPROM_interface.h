


#ifndef  _MCAL_EEPROM_INTERFACE_H
#define  _MCAL_EEPROM_INTERFACE_H


void EEPROM_voidWrite(u16 copy_u16Address, u8 copy_u8Data);

u8 EEPROM_voidRead(u16 copy_u16Address);

#endif