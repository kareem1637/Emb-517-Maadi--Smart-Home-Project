#ifndef _HAL_EXTI_CONFIG_H_
#define _HAL_EXTI_CONFIG_H_

#endif