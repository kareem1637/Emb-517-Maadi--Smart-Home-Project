

#ifndef LM35_PRIVATE_H
#define LM35_PRIVATE_H


#endif