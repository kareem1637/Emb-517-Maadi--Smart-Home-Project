#ifndef _HAL_LCD_CONFIG_H_
#define _HAL_LCD_CONFIG_H_


#endif