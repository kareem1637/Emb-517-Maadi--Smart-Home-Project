#ifndef _HAL_KPD_PRIVATE_H_
#define _HAL_KPD_PRIVATE_H_


#endif