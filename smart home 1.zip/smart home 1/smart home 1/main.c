
#include <stdio.h>
#include "Types.h"
#include "LCD_interface.h"
#include "util/delay.h"
#include "DIO_interface.h"
#include "string.h"
#include <stdlib.h>
#include "EEPROM_interface.h"
#include <avr/eeprom.h>
#include "LED_interface.h"
#include "uart.h"
char text[100];
#define F+_CPU 8000000UL
char rec[150];
void main(void){
	LCD_vidInit(GPIOB,GPIOA,PIN0,GPIOA,PIN1);
	KPD_vidInit(GPIOC,HIGH_NIBBLE,LOW_NIBBLE);
	int flage=0;
	int firstime =0;
	LED_vidLEDInit(GPIOA,PIN3);
	LED_vidLEDInit(GPIOD,PIN2);
	LED_vidLEDInit(GPIOD,PIN3);
    LED_vidLEDInit(GPIOD,PIN4);
	LED_vidLEDInit(GPIOD,PIN5);
	LED_vidLEDInit(GPIOA,PIN5);
	DIO_vidSetPinMode(GPIOA, PIN6, OUTPUT);
	UART_init();
	LM35_vidInit(PIN7);
	
	while(1){
	check_temp();
	//char rec=UART_recieveByte();
u8 cmd =KPD_u8GetPressedKey(GPIOC,HIGH_NIBBLE,LOW_NIBBLE);
if(cmd=='A'){
	LCD_vidSendCmd(GPIOB,GPIOA,PIN0,GPIOA,PIN1,0x01);
	 sprintf(text, "admin press 1 ");
	displaystring(text);
	LCD_vidSendCmd(GPIOB,GPIOA,PIN0,GPIOA,PIN1,0xC0);
	sprintf(text,"user press 2 ");
	displaystring(text);
	 flage=1;
}

while(flage){
	check_temp();
	u8 cmd =KPD_u8GetPressedKey(GPIOC,HIGH_NIBBLE,LOW_NIBBLE);
	//char rec=UART_recieveByte();
 if (cmd=='1'|rec=='1'){
	LCD_vidSendCmd(GPIOB,GPIOA,PIN0,GPIOA,PIN1,0x01);
	sprintf(text, "admin mode ");
	displaystring(text);
	_delay_ms(4000);
	if(firstime==0){
		LCD_vidSendCmd(GPIOB,GPIOA,PIN0,GPIOA,PIN1,0x01);
		sprintf(text, "set new password ");
		displaystring(text);
		int i=0 ;
		u8 newpass [4];
		_delay_ms(6000);
		LCD_vidSendCmd(GPIOB,GPIOA,PIN0,GPIOA,PIN1,0x01);
		while(1){
			check_temp();
			u8 cmd =KPD_u8GetPressedKey(GPIOC,HIGH_NIBBLE,LOW_NIBBLE);
			//char rec=UART_recieveByte();
			if(cmd=='1' || cmd=='2' || cmd=='3' ||cmd=='4' ||cmd=='5' || cmd=='6' ||cmd=='7' || cmd=='8'|| cmd=='9' || cmd=='0'||rec=='1' || rec=='2' || rec=='3' ||rec=='4' ||rec=='5' || rec=='6' ||rec=='7' || rec=='8'|| rec=='9' || rec=='0'){
			newpass[i]=cmd;
			i++;
			LCD_vidDisplayChar(GPIOB,GPIOA,PIN0,GPIOA,PIN1,cmd);
			_delay_ms(2000);
			}
			if(i==4){
				eeprom_update_block((const void*)newpass, (void*)0x0010, 4);
                LCD_vidSendCmd(GPIOB,GPIOA,PIN0,GPIOA,PIN1,0x01);
                sprintf(text, "new pass: ");
                displaystring(text);
				u8 pass[4];
				eeprom_read_block((void*)pass, (const void*)0x0010, 4);
                displaystring(pass);
                LCD_vidSendCmd(GPIOB,GPIOA,PIN0,GPIOA,PIN1,0xC0);
                sprintf(text,"1:confirm");
                displaystring(text);		
				firstime=1;		
				break;
			}
			
		}
	}
		
	else if (firstime==1){
		LCD_vidSendCmd(GPIOB,GPIOA,PIN0,GPIOA,PIN1,0x01);
		 sprintf(text, "pass: ");
		 displaystring(text);
		 int x=0;
		 int trial=0;
		 u8 enteredpass[4];
		 u8 pass[4];
		 eeprom_read_block((void*)pass, (const void*)0x0010, 4);
		while (1){
			u8 cmd =KPD_u8GetPressedKey(GPIOC,HIGH_NIBBLE,LOW_NIBBLE);
			//char rec=UART_recieveByte();
			if(cmd=='1' || cmd=='2' || cmd=='3' ||cmd=='4' ||cmd=='5' || cmd=='6' ||cmd=='7' || cmd=='8'|| cmd=='9' || cmd=='0'||rec=='1' || rec=='2' || rec=='3' ||rec=='4' ||rec=='5' || rec=='6' ||rec=='7' || rec=='8'|| rec=='9' || rec=='0'){
				enteredpass[x]=cmd;
				x++;
				LCD_vidDisplayChar(GPIOB,GPIOA,PIN0,GPIOA,PIN1,cmd);
				_delay_ms(2000);
			}
			if(x==4){
                int flage=checkpass(enteredpass,pass);
				if(flage==1){
				LCD_vidSendCmd(GPIOB,GPIOA,PIN0,GPIOA,PIN1,0x01);
				sprintf(text, "confirmed ");
				displaystring(text);
				flage=0;
				break;}
				else{
					if(trial<2){
					LCD_vidSendCmd(GPIOB,GPIOA,PIN0,GPIOA,PIN1,0x01);
					sprintf(text, "wrong pass ");
					displaystring(text);
					_delay_ms(6000);
					LCD_vidSendCmd(GPIOB,GPIOA,PIN0,GPIOA,PIN1,0x01);
					sprintf(text, "try again ");
					displaystring(text);
					_delay_ms(6000);
					LCD_vidSendCmd(GPIOB,GPIOA,PIN0,GPIOA,PIN1,0x01);
					x=0;
					trial++;
					sprintf(text, "pass: ");
					displaystring(text);}
					else{
						LED_vidLEDInit(GPIOA,PIN2);
						LED_vidLEDOn(GPIOA,PIN2);
						LCD_vidSendCmd(GPIOB,GPIOA,PIN0,GPIOA,PIN1,0x01);
						sprintf(text, "theif!!!!! ");
						displaystring(text);
						
					}
				}
			}
	}
	
		
	}
 
	check_temp();
	LCD_vidSendCmd(GPIOB,GPIOA,PIN0,GPIOA,PIN1,0x01);
	sprintf(text, "1:Leds 2:door ");
	displaystring(text);
	LCD_vidSendCmd(GPIOB,GPIOA,PIN0,GPIOA,PIN1,0xC0);
	sprintf(text, "3:air cond  ");
	displaystring(text);
	while (1){
		check_temp();
		u8 cmd =KPD_u8GetPressedKey(GPIOC,HIGH_NIBBLE,LOW_NIBBLE);
		//char rec=UART_recieveByte();
		if(cmd == '1'|| rec=='1'){
			LCD_vidSendCmd(GPIOB,GPIOA,PIN0,GPIOA,PIN1,0x01);
			sprintf(text, "LED1 LED2 LED3");
			displaystring(text);
			LCD_vidSendCmd(GPIOB,GPIOA,PIN0,GPIOA,PIN1,0xC0);
			sprintf(text,"LED4 LED5 Dimmer");
			displaystring(text);
			_delay_ms(2000);
			while (1){
				check_temp();
				u8 cmd =KPD_u8GetPressedKey(GPIOC,HIGH_NIBBLE,LOW_NIBBLE);
				//char rec=UART_recieveByte();
				if(cmd == '1'||rec=='1'){
					LED_vidLEDToggle(GPIOA,PIN3);
				}
			    if(cmd == '2'||rec=='2'){
					LED_vidLEDToggle(GPIOD,PIN2);
				}
				if(cmd == '3'||rec=='3'){
					LED_vidLEDToggle(GPIOD,PIN3);
				}
				if(cmd == '4'||rec=='4'){
					LED_vidLEDToggle(GPIOD,PIN4);
				}
				if(cmd == '5'||rec=='5'){
					LED_vidLEDToggle(GPIOD,PIN5);
				}
						
			}
		}
		if(cmd == '2'|| rec=='2'){
			
			check_temp();
			LCD_vidSendCmd(GPIOB,GPIOA,PIN0,GPIOA,PIN1,0x01);
			sprintf(text, "DOOR OPEN");
			displaystring(text);
			while(1){
				u8 cmd =KPD_u8GetPressedKey(GPIOC,HIGH_NIBBLE,LOW_NIBBLE);
				//char rec=UART_recieveByte();
				if(cmd == '0'||rec=='0'){
					break;
				}
	        DIO_vidWritePin(GPIOA, PIN6, HIGH);
			_delay_us(1500);
		    DIO_vidWritePin(GPIOA, PIN6, LOW);	
			}
		}
		if(cmd == '3'||rec=='3'){
			check_temp();
			LCD_vidSendCmd(GPIOB,GPIOA,PIN0,GPIOA,PIN1,0x01);
			sprintf(text, "Air Conditioner");
			displaystring(text);
			DIO_vidWritePin(GPIOA, PIN5, HIGH);
	
}	
		}
	}
else if (cmd=='2'||rec=='2'){
	LCD_vidSendCmd(GPIOB,GPIOA,PIN0,GPIOA,PIN1,0x01);
	 sprintf(text, "user mode ");
	displaystring(text);
	_delay_ms(4000);
check_temp();
LCD_vidSendCmd(GPIOB,GPIOA,PIN0,GPIOA,PIN1,0x01);
sprintf(text, "1:Leds  ");
displaystring(text);
LCD_vidSendCmd(GPIOB,GPIOA,PIN0,GPIOA,PIN1,0xC0);
sprintf(text, "3:air cond  ");
displaystring(text);
while (1){
	check_temp();
	u8 cmd =KPD_u8GetPressedKey(GPIOC,HIGH_NIBBLE,LOW_NIBBLE);
	//char rec=UART_recieveByte();
	if(cmd == '1'||rec=='1'){
		LCD_vidSendCmd(GPIOB,GPIOA,PIN0,GPIOA,PIN1,0x01);
		sprintf(text, "LED1 LED2 LED3");
		displaystring(text);
		LCD_vidSendCmd(GPIOB,GPIOA,PIN0,GPIOA,PIN1,0xC0);
		sprintf(text,"LED4 LED5 Dimmer");
		displaystring(text);
		_delay_ms(2000);
		while (1){
			check_temp();
			u8 cmd =KPD_u8GetPressedKey(GPIOC,HIGH_NIBBLE,LOW_NIBBLE);
			//char rec=UART_recieveByte();
			if(cmd == '1'||rec=='1'){
				LED_vidLEDToggle(GPIOA,PIN3);
			}
			if(cmd == '2'||rec=='2'){
				LED_vidLEDToggle(GPIOD,PIN2);
			}
			if(cmd == '3'||rec=='3'){
				LED_vidLEDToggle(GPIOD,PIN3);
			}
			if(cmd == '4'||rec=='4'){
				LED_vidLEDToggle(GPIOD,PIN4);
			}
			if(cmd == '5'||rec=='5'){
				LED_vidLEDToggle(GPIOD,PIN5);
			}
			
		}
	}
}
if(cmd == '2'||rec=='2'){
	check_temp();
	LCD_vidSendCmd(GPIOB,GPIOA,PIN0,GPIOA,PIN1,0x01);
	sprintf(text, "Air Conditioner");
	displaystring(text);
	DIO_vidWritePin(GPIOA, PIN5, HIGH);
	
}
}

	}

}
	}
void  displaystring(char text [] ){
	int i ;
	for(i=0; i<strlen(text); i++){
	LCD_vidDisplayChar(GPIOB,GPIOA,PIN0,GPIOA,PIN1,text [i]);}

}
int checkpass(u8 pass1[],u8 pass2[]){
	int i=0;
	int flage=0;
	for (i=0;i<4;i++){
		if(pass1[i]!=pass2[i]){
			return flage;
		}
	
}
flage=1;
return flage;
}
void check_temp(void){
LED_vidLEDOff(GPIOA,PIN5);
if(LM35_u8Read() <= 30){
LED_vidLEDOn(GPIOA,PIN5);}
}
