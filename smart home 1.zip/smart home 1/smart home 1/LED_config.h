#ifndef _HAL_LED_CONFIG_H_
#define _HAL_LED_CONFIG_H_


#endif